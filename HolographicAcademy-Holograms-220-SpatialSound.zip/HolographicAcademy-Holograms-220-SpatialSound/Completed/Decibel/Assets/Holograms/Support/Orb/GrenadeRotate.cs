﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.

using UnityEngine;

namespace Academy
{
    public class GrenadeRotate : MonoBehaviour
    {
        public Color EmissiveColor = new Vector4(0f, .87f, 1f, 1f);

        void Start()
        {
            var materials = GetComponent<Renderer>().materials;
            materials[1].SetColor("_EmissionColor", EmissiveColor);
            GameObject childParticle = transform.Find("ParticleTrail").gameObject;
            if (childParticle != null)
            {
                ParticleSystem.MainModule ps = childParticle.GetComponent<ParticleSystem>().main;
                ps.startColor = EmissiveColor;
            }
        }
    }
}