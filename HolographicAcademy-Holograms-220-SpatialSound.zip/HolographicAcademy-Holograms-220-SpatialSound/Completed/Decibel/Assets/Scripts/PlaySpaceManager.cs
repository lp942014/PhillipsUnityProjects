﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.

using HoloToolkit.Unity;
using HoloToolkit.Unity.SpatialMapping;
using System.Collections.Generic;
using UnityEngine;

namespace Academy
{
    /// <summary>
    /// The SurfaceManager class allows applications to scan the environment for a specified amount of time 
    /// and then process the Spatial Mapping Mesh (find planes, remove vertices) after that time has expired.
    /// </summary>
    public class PlaySpaceManager : Singleton<PlaySpaceManager>
    {
        [Tooltip("When checked, the SurfaceObserver will stop running after a specified amount of time.")]
        public bool limitScanningByTime = true;

        [Tooltip("How much time (in seconds) that the SurfaceObserver will run after being started; used when 'Limit Scanning By Time' is checked.")]
        public float scanTime = 30.0f;

        [Tooltip("Material to use when rendering Spatial Mapping meshes while the observer is running.")]
        public Material defaultMaterial;

        [Tooltip("Optional Material to use when rendering Spatial Mapping meshes after the observer has been stopped.")]
        public Material secondaryMaterial;

        [Tooltip("Minimum number of floor planes required in order to exit scanning/processing mode.")]
        public uint minimumFloors = 1;

        public GameObject Poly;
        public GameObject PolyCharger;

        /// <summary>
        /// Indicates if processing of the surface meshes is complete.
        /// </summary>
        private bool meshesProcessed = false;

        /// <summary>
        /// GameObject initialization.
        /// </summary>
        private void Start()
        {
            // Update surfaceObserver and storedMeshes to use the same material during scanning.
            SpatialMappingManager.Instance.SetSurfaceMaterial(defaultMaterial);

            // Register for the MakePlanesComplete event.
            SurfaceMeshesToPlanes.Instance.MakePlanesComplete += SurfaceMeshesToPlanes_MakePlanesComplete;
        }

        /// <summary>
        /// Called once per frame.
        /// </summary>
        private void Update()
        {
            // Check to see if the spatial mapping data has been processed
            // and if we are limiting how much time the user can spend scanning.
            if (!meshesProcessed && limitScanningByTime)
            {
                // If we have not processed the spatial mapping data
                // and scanning time is limited...

                // Check to see if enough scanning time has passed
                // since starting the observer.
                if (limitScanningByTime && ((Time.time - SpatialMappingManager.Instance.StartTime) < scanTime))
                {
                    // If we have a limited scanning time, then we should wait until
                    // enough time has passed before processing the mesh.
                }
                else
                {
                    // The user should be done scanning their environment,
                    // so start processing the spatial mapping data...

                    if (SpatialMappingManager.Instance.IsObserverRunning())
                    {
                        // Stop the observer.
                        SpatialMappingManager.Instance.StopObserver();
                    }

                    // Generate planes.
                    CreatePlanes();
                    meshesProcessed = true;
                }
            }
        }

        /// <summary>
        /// Handler for the SurfaceMeshesToPlanes MakePlanesComplete event.
        /// </summary>
        /// <param name="source">Source of the event.</param>
        /// <param name="args">Args for the event.</param>
        private void SurfaceMeshesToPlanes_MakePlanesComplete(object source, System.EventArgs args)
        {
            List<GameObject> floorPlanes = new List<GameObject>();

            // Get all floor planes.
            floorPlanes = SurfaceMeshesToPlanes.Instance.GetActivePlanes(PlaneTypes.Floor);
            foreach (GameObject floorPlane in floorPlanes)
            {
                // Mark the floorPlane object as being part of the floor.
                floorPlane.name = "Floor";
            }

            // Check to see if we have enough floor planes (minimumFloors)
            // to set holograms on in the world.
            if (floorPlanes.Count >= minimumFloors)
            {
                // We have enough floors and walls to place our holograms on...

                // Let's reduce our triangle count by removing triangles
                // from SpatialMapping meshes that intersect with our active planes.
                RemoveVertices(SurfaceMeshesToPlanes.Instance.ActivePlanes);

                // We can indicate to the user that scanning is over by
                // changing the material applied to the Spatial Mapping meshes.
                SpatialMappingManager.Instance.SetSurfaceMaterial(secondaryMaterial);
            }
            else
            {
                // We do not have enough floors...

                // Re-enter scanning mode so the user can find more surfaces.
                SpatialMappingManager.Instance.StartObserver();

                // Signal that we are to re-process spatial data after scanning completes.
                meshesProcessed = false;
            }
        }

        /// <summary>
        /// Creates planes from the spatial mapping surfaces.
        /// </summary>
        private void CreatePlanes()
        {
            // Generate planes based on the spatial map.
            SurfaceMeshesToPlanes surfaceToPlanes = SurfaceMeshesToPlanes.Instance;
            if (surfaceToPlanes != null && surfaceToPlanes.enabled)
            {
                surfaceToPlanes.MakePlanes();
            }
        }

        /// <summary>
        /// Removes triangles from the spatial mapping surfaces.
        /// </summary>
        /// <param name="boundingObjects"></param>
        private void RemoveVertices(IEnumerable<GameObject> boundingObjects)
        {
            RemoveSurfaceVertices removeVerts = RemoveSurfaceVertices.Instance;
            if (removeVerts != null && removeVerts.enabled)
            {
                removeVerts.RemoveSurfaceVerticesWithinBounds(boundingObjects);
            }
        }

        /// <summary>
        /// Called when the GameObject is unloaded.
        /// </summary>
        protected override void OnDestroy()
        {
            base.OnDestroy();

            if (SurfaceMeshesToPlanes.Instance != null)
            {
                SurfaceMeshesToPlanes.Instance.MakePlanesComplete -= SurfaceMeshesToPlanes_MakePlanesComplete;
            }
        }
    }
}